import { createContext, useContext, useState, ReactNode } from "react";

export interface MatriculaData {
  codigo: string;
  nombre: string;
  carrera: string;
  ciclo: string;
  turno: string;
  cursos: string[];
  // Calculated
  cantidad: number;
  subtotal: number;
  descuento: number;
  recargo: number;
  total: number;
}

interface MatriculaContextType {
  data: MatriculaData | null;
  setData: (d: MatriculaData) => void;
  clear: () => void;
}

const MatriculaContext = createContext<MatriculaContextType | null>(null);

export function MatriculaProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<MatriculaData | null>(null);
  return (
    <MatriculaContext.Provider value={{ data, setData, clear: () => setData(null) }}>
      {children}
    </MatriculaContext.Provider>
  );
}

export function useMatricula() {
  const ctx = useContext(MatriculaContext);
  if (!ctx) throw new Error("useMatricula must be used inside MatriculaProvider");
  return ctx;
}
