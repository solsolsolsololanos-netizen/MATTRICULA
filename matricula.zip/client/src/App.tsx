import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { MatriculaProvider } from "./contexts/MatriculaContext";
import Vista from "./pages/Vista";
import Formulario from "./pages/Formulario";
import Resultado from "./pages/Resultado";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Vista} />
      <Route path="/formulario" component={Formulario} />
      <Route path="/resultado" component={Resultado} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <MatriculaProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </MatriculaProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
