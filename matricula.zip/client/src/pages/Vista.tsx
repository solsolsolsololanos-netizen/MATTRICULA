/**
 * Vista.tsx — Pantalla de presentación del sistema de matrícula
 * Diseño: Elegancia Institucional con Profundidad
 * Paleta: #401F28 (vino) / #E9E2DA (crema) / #B5C5D4 (azul suave)
 * Tipografía: Cormorant Garamond (display) + Inter (funcional)
 */
import { Link } from "wouter";
import { GraduationCap, BookOpen, Clock, DollarSign, ChevronRight } from "lucide-react";

const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663215935042/AeB6KCvwBzkf4KExoMjSv5/hero_presentacion-J6P5bQbBwxgoNW7w58DCo5.webp";
const PANEL_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663215935042/AeB6KCvwBzkf4KExoMjSv5/panel_decorativo-CpPWghqDTiDuMes5kZsgeM.webp";

const stats = [
  { icon: BookOpen, label: "Cursos disponibles", value: "6" },
  { icon: DollarSign, label: "Costo por curso", value: "S/ 150" },
  { icon: Clock, label: "Turnos disponibles", value: "3" },
];

const rules = [
  { num: "01", text: "Selecciona mínimo 3 cursos para completar tu matrícula." },
  { num: "02", text: "Más de 5 cursos aplica un 10% de descuento automático." },
  { num: "03", text: "El turno Noche aplica un recargo del 5% sobre el subtotal." },
  { num: "04", text: "Todos los campos son obligatorios para procesar la ficha." },
];

export default function Vista() {
  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: "#E9E2DA" }}>
      {/* Header */}
      <header
        className="sticky top-0 z-50 flex items-center justify-between px-6 py-4 border-b"
        style={{ backgroundColor: "#401F28", borderColor: "#5a2d3a" }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold"
            style={{ backgroundColor: "#E9E2DA", color: "#401F28" }}
          >
            M
          </div>
          <div>
            <p className="text-sm font-semibold leading-none" style={{ color: "#E9E2DA", fontFamily: "'Cormorant Garamond', serif" }}>
              Matrícula
            </p>
            <p className="text-xs leading-none mt-0.5" style={{ color: "#B5C5D4" }}>
              Proyecto Final · SENATI
            </p>
          </div>
        </div>
        <Link href="/formulario">
          <button
            className="flex items-center gap-2 px-4 py-2 rounded text-sm font-medium transition-all duration-200 hover:opacity-90 active:scale-95"
            style={{ backgroundColor: "#E9E2DA", color: "#401F28" }}
          >
            Ir al formulario <ChevronRight size={14} />
          </button>
        </Link>
      </header>

      {/* Hero section */}
      <section
        className="relative overflow-hidden flex flex-col justify-end"
        style={{
          minHeight: "520px",
          backgroundImage: `url(${HERO_BG})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(to top, rgba(64,31,40,0.92) 0%, rgba(64,31,40,0.45) 55%, transparent 100%)" }}
        />
        <div className="relative z-10 container py-14 animate-fade-up">
          <span
            className="inline-block text-xs font-semibold tracking-widest uppercase mb-4 px-3 py-1 rounded-full"
            style={{ backgroundColor: "rgba(181,197,212,0.22)", color: "#B5C5D4", border: "1px solid rgba(181,197,212,0.35)" }}
          >
            Inscripción Académica
          </span>
          <h1
            className="text-5xl md:text-7xl font-bold leading-none mb-4"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: "#E9E2DA" }}
          >
            Formulario de<br />
            <em className="not-italic" style={{ color: "#B5C5D4" }}>Requerimientos</em>
          </h1>
          <p className="text-base max-w-xl mb-8" style={{ color: "rgba(233,226,218,0.78)" }}>
            Sistema web desarrollado en HTML, CSS y PHP para calcular el costo de matrícula de un estudiante aplicando formularios, validaciones y lógica de negocio.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link href="/formulario">
              <button
                className="flex items-center gap-2 px-6 py-3 rounded font-semibold text-sm transition-all duration-200 hover:opacity-90 active:scale-95 animate-pulse-ring"
                style={{ backgroundColor: "#E9E2DA", color: "#401F28" }}
              >
                <GraduationCap size={16} />
                Iniciar matrícula
              </button>
            </Link>
          </div>
        </div>

        {/* Stats bar */}
        <div
          className="relative z-10 border-t"
          style={{ backgroundColor: "rgba(64,31,40,0.85)", borderColor: "rgba(181,197,212,0.2)", backdropFilter: "blur(8px)" }}
        >
          <div className="container">
            <div className="grid grid-cols-3 divide-x divide-[rgba(181,197,212,0.2)]">
              {stats.map(({ icon: Icon, label, value }) => (
                <div key={label} className="flex items-center gap-3 py-4 px-2 md:px-6">
                  <Icon size={20} style={{ color: "#B5C5D4" }} />
                  <div>
                    <p className="text-xl font-bold leading-none" style={{ color: "#E9E2DA", fontFamily: "'Cormorant Garamond', serif" }}>
                      {value}
                    </p>
                    <p className="text-xs mt-0.5" style={{ color: "rgba(181,197,212,0.8)" }}>{label}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Main content: rules + decorative panel */}
      <main className="container py-16 flex-1">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Rules */}
          <div className="animate-fade-up" style={{ animationDelay: "0.1s" }}>
            <span
              className="inline-block text-xs font-semibold tracking-widest uppercase mb-6"
              style={{ color: "#B5C5D4" }}
            >
              Reglas de negocio
            </span>
            <h2
              className="text-4xl font-bold mb-8 leading-tight"
              style={{ fontFamily: "'Cormorant Garamond', serif", color: "#401F28" }}
            >
              Lo que debes saber antes de matricularte
            </h2>

            <div className="space-y-5">
              {rules.map(({ num, text }) => (
                <div
                  key={num}
                  className="flex gap-5 p-5 rounded-lg transition-all duration-200 hover:shadow-md"
                  style={{
                    backgroundColor: "rgba(255,255,255,0.55)",
                    border: "1px solid rgba(64,31,40,0.1)",
                    borderLeft: "3px solid #401F28",
                  }}
                >
                  <span
                    className="text-3xl font-bold leading-none flex-shrink-0"
                    style={{ fontFamily: "'Cormorant Garamond', serif", color: "rgba(64,31,40,0.25)" }}
                  >
                    {num}
                  </span>
                  <p className="text-sm leading-relaxed pt-1" style={{ color: "#401F28" }}>
                    {text}
                  </p>
                </div>
              ))}
            </div>

            {/* Courses */}
            <div className="mt-10">
              <span
                className="inline-block text-xs font-semibold tracking-widest uppercase mb-4"
                style={{ color: "#B5C5D4" }}
              >
                Cursos disponibles
              </span>
              <div className="flex flex-wrap gap-2">
                {["Programación", "Base de Datos", "Redes", "Diseño Web", "Matemática", "Algoritmos"].map((c) => (
                  <span
                    key={c}
                    className="px-3 py-1.5 rounded text-sm font-medium"
                    style={{
                      backgroundColor: "rgba(64,31,40,0.08)",
                      color: "#401F28",
                      border: "1px solid rgba(64,31,40,0.18)",
                    }}
                  >
                    {c}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-10">
              <Link href="/formulario">
                <button
                  className="w-full flex items-center justify-center gap-2 py-4 rounded-lg font-semibold text-base transition-all duration-200 hover:opacity-90 active:scale-[0.98]"
                  style={{ backgroundColor: "#401F28", color: "#E9E2DA" }}
                >
                  <GraduationCap size={18} />
                  Completar formulario de matrícula
                </button>
              </Link>
            </div>
          </div>

          {/* Decorative panel */}
          <div className="animate-slide-in" style={{ animationDelay: "0.2s" }}>
            <div
              className="relative rounded-2xl overflow-hidden shadow-2xl"
              style={{ aspectRatio: "3/4", maxHeight: "600px" }}
            >
              <img
                src={PANEL_IMG}
                alt="Panel decorativo académico"
                className="w-full h-full object-cover"
              />
              {/* Overlay card */}
              <div
                className="absolute bottom-0 left-0 right-0 p-6"
                style={{
                  background: "linear-gradient(to top, rgba(64,31,40,0.95) 0%, transparent 100%)",
                }}
              >
                <p className="text-xs font-semibold tracking-widest uppercase mb-2" style={{ color: "#B5C5D4" }}>
                  Resultado esperado
                </p>
                <h3
                  className="text-2xl font-bold mb-3"
                  style={{ fontFamily: "'Cormorant Garamond', serif", color: "#E9E2DA" }}
                >
                  Ficha de Matrícula
                </h3>
                <div className="space-y-1.5">
                  {["Código y nombre del estudiante", "Carrera, ciclo y turno", "Cursos seleccionados", "Subtotal, descuento y total a pagar"].map((item) => (
                    <div key={item} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: "#B5C5D4" }} />
                      <p className="text-sm" style={{ color: "rgba(233,226,218,0.82)" }}>{item}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer
        className="py-6 text-center text-xs border-t"
        style={{ backgroundColor: "#401F28", color: "rgba(181,197,212,0.7)", borderColor: "#5a2d3a" }}
      >
        Instructor: Ing. Florial Rodríguez Rabanal · SENATI — Proyecto Final
      </footer>
    </div>
  );
}
