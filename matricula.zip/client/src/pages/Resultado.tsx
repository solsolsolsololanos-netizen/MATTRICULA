/**
 * Resultado.tsx — Ficha de Matrícula final
 * Paleta: #401F28 (vino) / #E9E2DA (crema) / #B5C5D4 (azul suave)
 */
import { Link, useLocation } from "wouter";
import { useMatricula } from "@/contexts/MatriculaContext";
import { GraduationCap, ChevronLeft, Printer, RotateCcw } from "lucide-react";

const FICHA_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663215935042/AeB6KCvwBzkf4KExoMjSv5/ficha_bg-idh5v6iDJ2pe24Lp4r4qUF.webp";

export default function Resultado() {
  const { data, clear } = useMatricula();
  const [, navigate] = useLocation();

  if (!data) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-6" style={{ backgroundColor: "#E9E2DA" }}>
        <GraduationCap size={48} style={{ color: "#401F28" }} />
        <p className="text-lg font-semibold" style={{ color: "#401F28", fontFamily: "'Cormorant Garamond', serif" }}>
          No hay datos de matrícula disponibles.
        </p>
        <Link href="/formulario">
          <button
            className="px-6 py-3 rounded-lg font-medium text-sm"
            style={{ backgroundColor: "#401F28", color: "#E9E2DA" }}
          >
            Ir al formulario
          </button>
        </Link>
      </div>
    );
  }

  function handleNueva() {
    clear();
    navigate("/formulario");
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#E9E2DA" }}>
      {/* Header */}
      <header
        className="sticky top-0 z-50 flex items-center justify-between px-6 py-4 border-b print:hidden"
        style={{ backgroundColor: "#401F28", borderColor: "#5a2d3a" }}
      >
        <Link href="/formulario">
          <button className="flex items-center gap-2 text-sm transition-opacity hover:opacity-75" style={{ color: "#B5C5D4" }}>
            <ChevronLeft size={16} /> Volver
          </button>
        </Link>
        <span className="text-sm font-semibold" style={{ color: "#E9E2DA", fontFamily: "'Cormorant Garamond', serif" }}>
          Ficha de Matrícula
        </span>
        <div className="flex gap-2">
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-opacity hover:opacity-75"
            style={{ backgroundColor: "rgba(181,197,212,0.2)", color: "#B5C5D4", border: "1px solid rgba(181,197,212,0.3)" }}
          >
            <Printer size={13} /> Imprimir
          </button>
        </div>
      </header>

      <div className="container py-10 animate-fade-up">
        {/* Success banner */}
        <div
          className="flex items-center gap-4 p-5 rounded-xl mb-8"
          style={{ backgroundColor: "rgba(64,31,40,0.08)", border: "1px solid rgba(64,31,40,0.15)" }}
        >
          <div
            className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
            style={{ backgroundColor: "#401F28" }}
          >
            <GraduationCap size={22} style={{ color: "#E9E2DA" }} />
          </div>
          <div>
            <h1 className="text-2xl font-bold leading-none" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#401F28" }}>
              ¡Matrícula registrada exitosamente!
            </h1>
            <p className="text-sm mt-1" style={{ color: "rgba(64,31,40,0.65)" }}>
              A continuación se muestra tu ficha de matrícula con el resumen completo.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Ficha principal */}
          <div className="lg:col-span-3">
            <div
              className="relative rounded-2xl overflow-hidden shadow-2xl"
              style={{ backgroundImage: `url(${FICHA_BG})`, backgroundSize: "cover", backgroundPosition: "center" }}
            >
              <div className="absolute inset-0" style={{ backgroundColor: "rgba(64,31,40,0.88)" }} />
              <div className="relative z-10 p-8">
                {/* Ficha header */}
                <div className="flex items-start justify-between mb-8">
                  <div>
                    <p className="text-xs font-semibold tracking-widest uppercase mb-1" style={{ color: "#B5C5D4" }}>
                      SENATI — Proyecto Final
                    </p>
                    <h2 className="text-4xl font-bold" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#E9E2DA" }}>
                      Ficha de<br />Matrícula
                    </h2>
                  </div>
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold"
                    style={{ backgroundColor: "rgba(233,226,218,0.15)", border: "2px solid rgba(181,197,212,0.4)", color: "#E9E2DA", fontFamily: "'Cormorant Garamond', serif" }}
                  >
                    {data.nombre.charAt(0).toUpperCase()}
                  </div>
                </div>

                {/* Student info */}
                <div className="space-y-4 mb-8">
                  <FichaRow label="Código" value={data.codigo} />
                  <FichaRow label="Nombre completo" value={data.nombre} />
                  <FichaRow label="Carrera" value={data.carrera} />
                  <FichaRow label="Ciclo" value={data.ciclo} />
                  <FichaRow label="Turno" value={data.turno} highlight={data.turno === "Noche"} />
                </div>

                {/* Courses */}
                <div className="mb-8">
                  <p className="text-xs font-semibold tracking-widest uppercase mb-3" style={{ color: "rgba(181,197,212,0.7)" }}>
                    Cursos matriculados ({data.cantidad})
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {data.cursos.map((c) => (
                      <span
                        key={c}
                        className="text-sm px-3 py-1.5 rounded-lg font-medium"
                        style={{ backgroundColor: "rgba(181,197,212,0.18)", color: "#B5C5D4", border: "1px solid rgba(181,197,212,0.28)" }}
                      >
                        {c}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Cost breakdown */}
                <div
                  className="rounded-xl p-5"
                  style={{ backgroundColor: "rgba(233,226,218,0.1)", border: "1px solid rgba(181,197,212,0.25)" }}
                >
                  <p className="text-xs font-semibold tracking-widest uppercase mb-4" style={{ color: "rgba(181,197,212,0.7)" }}>
                    Desglose de costos
                  </p>
                  <div className="space-y-2.5">
                    <CostRow label={`${data.cantidad} cursos × S/ 150`} value={`S/ ${data.subtotal.toFixed(2)}`} />
                    {data.descuento > 0 && (
                      <CostRow label="Descuento por volumen (10%)" value={`-S/ ${data.descuento.toFixed(2)}`} green />
                    )}
                    {data.recargo > 0 && (
                      <CostRow label="Recargo turno Noche (5%)" value={`+S/ ${data.recargo.toFixed(2)}`} red />
                    )}
                    <div className="border-t pt-3 mt-3" style={{ borderColor: "rgba(181,197,212,0.25)" }}>
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-base" style={{ color: "#E9E2DA" }}>Total a pagar</span>
                        <span className="text-3xl font-bold" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#B5C5D4" }}>
                          S/ {data.total.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Side info */}
          <div className="lg:col-span-2 space-y-5 animate-slide-in" style={{ animationDelay: "0.1s" }}>
            {/* Summary card */}
            <div
              className="rounded-xl p-6"
              style={{ backgroundColor: "rgba(255,255,255,0.6)", border: "1px solid rgba(64,31,40,0.12)", borderLeft: "3px solid #401F28" }}
            >
              <h3 className="text-xl font-bold mb-4" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#401F28" }}>
                Resumen de matrícula
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <MetricCard label="Cursos" value={`${data.cantidad}`} />
                <MetricCard label="Subtotal" value={`S/ ${data.subtotal.toFixed(2)}`} />
                {data.descuento > 0 && <MetricCard label="Descuento" value={`-S/ ${data.descuento.toFixed(2)}`} green />}
                {data.recargo > 0 && <MetricCard label="Recargo" value={`+S/ ${data.recargo.toFixed(2)}`} red />}
              </div>
              <div
                className="mt-4 p-4 rounded-lg text-center"
                style={{ backgroundColor: "#401F28" }}
              >
                <p className="text-xs mb-1" style={{ color: "rgba(181,197,212,0.7)" }}>Total a pagar</p>
                <p className="text-4xl font-bold" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#B5C5D4" }}>
                  S/ {data.total.toFixed(2)}
                </p>
              </div>
            </div>

            {/* Conditions applied */}
            <div
              className="rounded-xl p-5"
              style={{ backgroundColor: "rgba(255,255,255,0.6)", border: "1px solid rgba(64,31,40,0.12)" }}
            >
              <p className="text-xs font-semibold tracking-widest uppercase mb-3" style={{ color: "#B5C5D4" }}>
                Condiciones aplicadas
              </p>
              <div className="space-y-2">
                <ConditionRow
                  active={data.descuento > 0}
                  text={data.descuento > 0 ? "Descuento del 10% aplicado (más de 5 cursos)" : "Sin descuento (5 cursos o menos)"}
                />
                <ConditionRow
                  active={data.recargo > 0}
                  warn
                  text={data.recargo > 0 ? "Recargo del 5% aplicado (turno Noche)" : "Sin recargo de turno Noche"}
                />
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-3 print:hidden">
              <button
                onClick={handleNueva}
                className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm transition-all duration-200 hover:opacity-90 active:scale-[0.98]"
                style={{ backgroundColor: "#401F28", color: "#E9E2DA" }}
              >
                <RotateCcw size={15} /> Registrar otra matrícula
              </button>
              <Link href="/">
                <button
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-medium text-sm transition-all duration-200 hover:opacity-80"
                  style={{ backgroundColor: "transparent", color: "#401F28", border: "1px solid rgba(64,31,40,0.25)" }}
                >
                  Volver al inicio
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FichaRow({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex justify-between items-center border-b pb-2" style={{ borderColor: "rgba(181,197,212,0.15)" }}>
      <span className="text-xs" style={{ color: "rgba(181,197,212,0.65)" }}>{label}</span>
      <span className="text-sm font-medium" style={{ color: highlight ? "#fde68a" : "#E9E2DA" }}>{value}</span>
    </div>
  );
}

function CostRow({ label, value, green, red }: { label: string; value: string; green?: boolean; red?: boolean }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-xs" style={{ color: "rgba(181,197,212,0.7)" }}>{label}</span>
      <span className="text-sm font-semibold" style={{ color: green ? "#86efac" : red ? "#fca5a5" : "rgba(233,226,218,0.9)" }}>
        {value}
      </span>
    </div>
  );
}

function MetricCard({ label, value, green, red }: { label: string; value: string; green?: boolean; red?: boolean }) {
  return (
    <div
      className="p-3 rounded-lg text-center"
      style={{ backgroundColor: "rgba(64,31,40,0.06)", border: "1px solid rgba(64,31,40,0.1)" }}
    >
      <p className="text-xs mb-1" style={{ color: "rgba(64,31,40,0.55)" }}>{label}</p>
      <p className="text-lg font-bold" style={{ fontFamily: "'Cormorant Garamond', serif", color: green ? "#16a34a" : red ? "#dc2626" : "#401F28" }}>
        {value}
      </p>
    </div>
  );
}

function ConditionRow({ active, warn, text }: { active: boolean; warn?: boolean; text: string }) {
  return (
    <div className="flex items-start gap-2">
      <div
        className="w-2 h-2 rounded-full flex-shrink-0 mt-1.5"
        style={{ backgroundColor: active ? (warn ? "#fca5a5" : "#86efac") : "rgba(64,31,40,0.2)" }}
      />
      <p className="text-xs" style={{ color: active ? "#401F28" : "rgba(64,31,40,0.5)" }}>{text}</p>
    </div>
  );
}
