/**
 * Formulario.tsx — Formulario de matrícula interactivo
 * Paleta: #401F28 (vino) / #E9E2DA (crema) / #B5C5D4 (azul suave)
 * Reglas: mín 3 cursos, S/150 c/u, >5 cursos → 10% dto, turno Noche → 5% recargo
 */
import { useState, useMemo } from "react";
import { Link, useLocation } from "wouter";
import { ChevronLeft, User, BookOpen, Clock, GraduationCap, AlertCircle, CheckCircle2 } from "lucide-react";
import { useMatricula } from "@/contexts/MatriculaContext";
import type { MatriculaData } from "@/contexts/MatriculaContext";

const CARRERAS = [
  "Computación e Informática",
  "Desarrollo de Software",
  "Base de Datos",
  "Redes y Seguridad",
  "Diseño Web",
];

const CICLOS = Array.from({ length: 10 }, (_, i) => `${i + 1}° Ciclo`);

const TURNOS_POR_CARRERA: Record<string, string[]> = {
  "Computación e Informática": ["Mañana", "Tarde", "Noche"],
  "Desarrollo de Software": ["Mañana", "Tarde"],
  "Base de Datos": ["Tarde", "Noche"],
  "Redes y Seguridad": ["Mañana", "Noche"],
  "Diseño Web": ["Mañana", "Tarde"],
};

const CURSOS = ["Programación", "Base de Datos", "Redes", "Diseño Web", "Matemática", "Algoritmos"];
const COSTO_CURSO = 150;

function calcular(cursos: string[], turno: string) {
  const cantidad = cursos.length;
  const subtotal = cantidad * COSTO_CURSO;
  const descuento = cantidad > 5 ? subtotal * 0.1 : 0;
  const baseConDesc = subtotal - descuento;
  const recargo = turno === "Noche" ? baseConDesc * 0.05 : 0;
  const total = baseConDesc + recargo;
  return { cantidad, subtotal, descuento, recargo, total };
}

interface Errors {
  codigo?: string;
  nombre?: string;
  carrera?: string;
  ciclo?: string;
  turno?: string;
  cursos?: string;
}

export default function Formulario() {
  const { setData } = useMatricula();
  const [, navigate] = useLocation();

  const [codigo, setCodigo] = useState("");
  const [nombre, setNombre] = useState("");
  const [carrera, setCarrera] = useState("");
  const [ciclo, setCiclo] = useState("");
  const [turno, setTurno] = useState("");
  const [cursos, setCursos] = useState<string[]>([]);
  const [errors, setErrors] = useState<Errors>({});
  const [submitted, setSubmitted] = useState(false);

  const turnosDisponibles = carrera ? (TURNOS_POR_CARRERA[carrera] ?? ["Mañana", "Tarde", "Noche"]) : ["Mañana", "Tarde", "Noche"];

  const calc = useMemo(() => calcular(cursos, turno), [cursos, turno]);

  function toggleCurso(c: string) {
    setCursos((prev) => prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]);
  }

  function validate(): Errors {
    const e: Errors = {};
    if (!codigo.trim()) e.codigo = "El código de estudiante es obligatorio.";
    else if (!/^\d{5,10}$/.test(codigo.trim())) e.codigo = "El código debe tener entre 5 y 10 dígitos numéricos.";
    if (!nombre.trim()) e.nombre = "El nombre completo es obligatorio.";
    else if (nombre.trim().length < 3) e.nombre = "El nombre debe tener al menos 3 caracteres.";
    if (!carrera) e.carrera = "Debe seleccionar una carrera.";
    if (!ciclo) e.ciclo = "Debe seleccionar un ciclo.";
    if (!turno) e.turno = "Debe seleccionar un turno.";
    else if (carrera && !turnosDisponibles.includes(turno)) e.turno = "El turno no está disponible para la carrera seleccionada.";
    if (cursos.length < 3) e.cursos = "Debe seleccionar al menos 3 cursos.";
    return e;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitted(true);
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    const result: MatriculaData = {
      codigo: codigo.trim(),
      nombre: nombre.trim(),
      carrera,
      ciclo,
      turno,
      cursos,
      ...calc,
    };
    setData(result);
    navigate("/resultado");
  }

  const fieldClass = (err?: string) =>
    `w-full px-4 py-3 rounded-lg text-sm outline-none transition-all duration-200 focus:ring-2 ${
      err
        ? "ring-2 ring-red-400 bg-red-50"
        : "focus:ring-[#401F28]/30"
    }`;

  const inputStyle = { backgroundColor: "rgba(255,255,255,0.7)", border: "1px solid rgba(64,31,40,0.18)", color: "#401F28" };
  const inputFocusStyle = { backgroundColor: "rgba(255,255,255,0.9)" };

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#E9E2DA" }}>
      {/* Header */}
      <header
        className="sticky top-0 z-50 flex items-center justify-between px-6 py-4 border-b"
        style={{ backgroundColor: "#401F28", borderColor: "#5a2d3a" }}
      >
        <Link href="/">
          <button className="flex items-center gap-2 text-sm transition-opacity hover:opacity-75" style={{ color: "#B5C5D4" }}>
            <ChevronLeft size={16} /> Volver
          </button>
        </Link>
        <div className="flex items-center gap-2">
          <GraduationCap size={18} style={{ color: "#B5C5D4" }} />
          <span className="text-sm font-semibold" style={{ color: "#E9E2DA", fontFamily: "'Cormorant Garamond', serif" }}>
            Formulario de Matrícula
          </span>
        </div>
        <div className="w-20" />
      </header>

      <div className="container py-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          {/* Form */}
          <form onSubmit={handleSubmit} noValidate className="lg:col-span-2 space-y-6 animate-fade-up">

            {/* Section 1: Datos del estudiante */}
            <div
              className="rounded-xl p-6 shadow-sm"
              style={{ backgroundColor: "rgba(255,255,255,0.6)", border: "1px solid rgba(64,31,40,0.1)", borderLeft: "3px solid #401F28" }}
            >
              <div className="flex items-center gap-3 mb-5">
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold" style={{ backgroundColor: "#401F28", color: "#E9E2DA" }}>
                  1
                </div>
                <div className="flex items-center gap-2">
                  <User size={16} style={{ color: "#401F28" }} />
                  <h2 className="text-xl font-bold" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#401F28" }}>
                    Datos del estudiante
                  </h2>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold mb-1.5 tracking-wide uppercase" style={{ color: "#401F28" }}>
                    Código de estudiante *
                  </label>
                  <input
                    type="text"
                    value={codigo}
                    onChange={(e) => setCodigo(e.target.value)}
                    placeholder="Ej: 1213232"
                    className={fieldClass(errors.codigo)}
                    style={inputStyle}
                    onFocus={(e) => Object.assign(e.target.style, inputFocusStyle)}
                    onBlur={(e) => Object.assign(e.target.style, inputStyle)}
                  />
                  {errors.codigo && (
                    <p className="flex items-center gap-1 text-xs mt-1.5 text-red-600">
                      <AlertCircle size={11} /> {errors.codigo}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-xs font-semibold mb-1.5 tracking-wide uppercase" style={{ color: "#401F28" }}>
                    Nombre completo *
                  </label>
                  <input
                    type="text"
                    value={nombre}
                    onChange={(e) => setNombre(e.target.value)}
                    placeholder="Ej: Gerardo López"
                    className={fieldClass(errors.nombre)}
                    style={inputStyle}
                    onFocus={(e) => Object.assign(e.target.style, inputFocusStyle)}
                    onBlur={(e) => Object.assign(e.target.style, inputStyle)}
                  />
                  {errors.nombre && (
                    <p className="flex items-center gap-1 text-xs mt-1.5 text-red-600">
                      <AlertCircle size={11} /> {errors.nombre}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Section 2: Selección académica */}
            <div
              className="rounded-xl p-6 shadow-sm"
              style={{ backgroundColor: "rgba(255,255,255,0.6)", border: "1px solid rgba(64,31,40,0.1)", borderLeft: "3px solid #B5C5D4" }}
            >
              <div className="flex items-center gap-3 mb-5">
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold" style={{ backgroundColor: "#B5C5D4", color: "#401F28" }}>
                  2
                </div>
                <div className="flex items-center gap-2">
                  <BookOpen size={16} style={{ color: "#401F28" }} />
                  <h2 className="text-xl font-bold" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#401F28" }}>
                    Selección académica
                  </h2>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-xs font-semibold mb-1.5 tracking-wide uppercase" style={{ color: "#401F28" }}>
                    Carrera *
                  </label>
                  <select
                    value={carrera}
                    onChange={(e) => { setCarrera(e.target.value); setTurno(""); }}
                    className={fieldClass(errors.carrera)}
                    style={inputStyle}
                  >
                    <option value="">Seleccionar carrera…</option>
                    {CARRERAS.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                  {errors.carrera && (
                    <p className="flex items-center gap-1 text-xs mt-1.5 text-red-600">
                      <AlertCircle size={11} /> {errors.carrera}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-xs font-semibold mb-1.5 tracking-wide uppercase" style={{ color: "#401F28" }}>
                    Ciclo *
                  </label>
                  <select
                    value={ciclo}
                    onChange={(e) => setCiclo(e.target.value)}
                    className={fieldClass(errors.ciclo)}
                    style={inputStyle}
                  >
                    <option value="">Seleccionar ciclo…</option>
                    {CICLOS.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                  {errors.ciclo && (
                    <p className="flex items-center gap-1 text-xs mt-1.5 text-red-600">
                      <AlertCircle size={11} /> {errors.ciclo}
                    </p>
                  )}
                </div>
              </div>

              {/* Turno */}
              <div>
                <label className="flex items-center gap-2 text-xs font-semibold mb-3 tracking-wide uppercase" style={{ color: "#401F28" }}>
                  <Clock size={13} /> Turno disponible para la carrera *
                </label>
                {carrera && (
                  <p className="text-xs mb-3" style={{ color: "#B5C5D4" }}>
                    Los turnos disponibles se determinan según la carrera seleccionada.
                  </p>
                )}
                <div className="flex flex-wrap gap-3">
                  {["Mañana", "Tarde", "Noche"].map((t) => {
                    const available = !carrera || turnosDisponibles.includes(t);
                    const selected = turno === t;
                    return (
                      <button
                        key={t}
                        type="button"
                        disabled={!available}
                        onClick={() => setTurno(t)}
                        className="px-5 py-2.5 rounded-lg text-sm font-medium transition-all duration-200"
                        style={{
                          backgroundColor: selected ? "#401F28" : available ? "rgba(255,255,255,0.7)" : "rgba(64,31,40,0.06)",
                          color: selected ? "#E9E2DA" : available ? "#401F28" : "rgba(64,31,40,0.35)",
                          border: selected ? "1px solid #401F28" : "1px solid rgba(64,31,40,0.18)",
                          opacity: available ? 1 : 0.5,
                          cursor: available ? "pointer" : "not-allowed",
                        }}
                      >
                        {t}
                      </button>
                    );
                  })}
                </div>
                {errors.turno && (
                  <p className="flex items-center gap-1 text-xs mt-2 text-red-600">
                    <AlertCircle size={11} /> {errors.turno}
                  </p>
                )}
              </div>
            </div>

            {/* Section 3: Cursos */}
            <div
              className="rounded-xl p-6 shadow-sm"
              style={{ backgroundColor: "rgba(255,255,255,0.6)", border: "1px solid rgba(64,31,40,0.1)", borderLeft: "3px solid #401F28" }}
            >
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold" style={{ backgroundColor: "#401F28", color: "#E9E2DA" }}>
                    3
                  </div>
                  <h2 className="text-xl font-bold" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#401F28" }}>
                    Cursos matriculados
                  </h2>
                </div>
                <span
                  className="text-xs font-semibold px-2.5 py-1 rounded-full"
                  style={{
                    backgroundColor: cursos.length >= 3 ? "#401F28" : "rgba(64,31,40,0.12)",
                    color: cursos.length >= 3 ? "#E9E2DA" : "#401F28",
                  }}
                >
                  {cursos.length} seleccionado{cursos.length !== 1 ? "s" : ""}
                </span>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {CURSOS.map((c) => {
                  const checked = cursos.includes(c);
                  return (
                    <button
                      key={c}
                      type="button"
                      onClick={() => toggleCurso(c)}
                      className="flex items-center gap-2.5 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 text-left"
                      style={{
                        backgroundColor: checked ? "#401F28" : "rgba(255,255,255,0.7)",
                        color: checked ? "#E9E2DA" : "#401F28",
                        border: checked ? "1px solid #401F28" : "1px solid rgba(64,31,40,0.18)",
                        transform: checked ? "scale(1.02)" : "scale(1)",
                      }}
                    >
                      <div
                        className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0"
                        style={{
                          backgroundColor: checked ? "#E9E2DA" : "transparent",
                          border: checked ? "none" : "1.5px solid rgba(64,31,40,0.35)",
                        }}
                      >
                        {checked && <CheckCircle2 size={12} style={{ color: "#401F28" }} />}
                      </div>
                      {c}
                    </button>
                  );
                })}
              </div>
              {errors.cursos && (
                <p className="flex items-center gap-1 text-xs mt-3 text-red-600">
                  <AlertCircle size={11} /> {errors.cursos}
                </p>
              )}
              <p className="text-xs mt-3" style={{ color: "rgba(64,31,40,0.55)" }}>
                Mínimo 3 cursos · S/ 150 por curso · Más de 5 cursos aplica 10% de descuento
              </p>
            </div>

            {/* Submit */}
            {submitted && Object.keys(errors).length > 0 && (
              <div
                className="flex items-start gap-3 p-4 rounded-lg animate-fade-up"
                style={{ backgroundColor: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)" }}
              >
                <AlertCircle size={16} className="text-red-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-700">
                  Por favor corrige los errores indicados antes de continuar.
                </p>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-4 rounded-xl font-semibold text-base transition-all duration-200 hover:opacity-90 active:scale-[0.98] flex items-center justify-center gap-2"
              style={{ backgroundColor: "#401F28", color: "#E9E2DA" }}
            >
              <GraduationCap size={18} />
              Enviar formulario y ver ficha
            </button>
          </form>

          {/* Live summary panel */}
          <aside className="animate-slide-in" style={{ animationDelay: "0.15s" }}>
            <div
              className="rounded-xl overflow-hidden shadow-lg sticky top-24"
              style={{ backgroundColor: "#401F28" }}
            >
              <div className="px-6 py-5 border-b" style={{ borderColor: "rgba(181,197,212,0.2)" }}>
                <p className="text-xs font-semibold tracking-widest uppercase mb-1" style={{ color: "#B5C5D4" }}>
                  Resumen automático
                </p>
                <h3 className="text-2xl font-bold" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#E9E2DA" }}>
                  Tu matrícula
                </h3>
              </div>
              <div className="px-6 py-5 space-y-4">
                <SummaryRow label="Carrera" value={carrera || "—"} />
                <SummaryRow label="Ciclo" value={ciclo || "—"} />
                <SummaryRow label="Turno" value={turno || "—"} highlight={turno === "Noche"} />
                <SummaryRow label="Cursos seleccionados" value={`${calc.cantidad}`} />
                <div className="border-t pt-4 space-y-3" style={{ borderColor: "rgba(181,197,212,0.2)" }}>
                  <SummaryRow label="Subtotal" value={`S/ ${calc.subtotal.toFixed(2)}`} />
                  {calc.descuento > 0 && (
                    <SummaryRow label="Descuento (10%)" value={`-S/ ${calc.descuento.toFixed(2)}`} accent />
                  )}
                  {calc.recargo > 0 && (
                    <SummaryRow label="Recargo Noche (5%)" value={`+S/ ${calc.recargo.toFixed(2)}`} warn />
                  )}
                  <div className="border-t pt-3" style={{ borderColor: "rgba(181,197,212,0.2)" }}>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-bold" style={{ color: "#E9E2DA" }}>Total a pagar</span>
                      <span className="text-2xl font-bold" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#B5C5D4" }}>
                        S/ {calc.total.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              {cursos.length > 0 && (
                <div className="px-6 pb-5">
                  <p className="text-xs font-semibold mb-2 tracking-wide uppercase" style={{ color: "rgba(181,197,212,0.7)" }}>
                    Cursos
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {cursos.map((c) => (
                      <span
                        key={c}
                        className="text-xs px-2 py-1 rounded"
                        style={{ backgroundColor: "rgba(181,197,212,0.18)", color: "#B5C5D4", border: "1px solid rgba(181,197,212,0.25)" }}
                      >
                        {c}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}

function SummaryRow({ label, value, accent, warn, highlight }: { label: string; value: string; accent?: boolean; warn?: boolean; highlight?: boolean }) {
  return (
    <div className="flex justify-between items-start gap-2">
      <span className="text-xs" style={{ color: "rgba(181,197,212,0.7)" }}>{label}</span>
      <span
        className="text-sm font-medium text-right"
        style={{
          color: accent ? "#86efac" : warn ? "#fca5a5" : highlight ? "#fde68a" : "rgba(233,226,218,0.9)",
        }}
      >
        {value}
      </span>
    </div>
  );
}
