# Ideas de Diseño — Matrícula Interactiva

## Paleta de color indicada por el usuario
- `#401F28` — Vino oscuro / Primario
- `#E9E2DA` — Crema cálida / Fondo claro
- `#B5C5D4` — Azul grisáceo / Acento suave

---

<response>
<probability>0.06</probability>
<text>

## Opción A — Editorial Académico

**Design Movement:** Diseño editorial universitario, inspirado en revistas de arquitectura y catálogos de moda.

**Core Principles:**
- Tipografía grande y dominante como elemento visual principal
- Contraste fuerte entre el vino oscuro y la crema cálida
- Asimetría deliberada en el layout (columna izquierda estrecha, derecha amplia)
- Formulario como objeto de diseño, no solo funcional

**Color Philosophy:** El vino `#401F28` transmite seriedad académica y distinción; la crema `#E9E2DA` aporta calidez y legibilidad; el azul grisáceo `#B5C5D4` actúa como acento frío que equilibra la calidez del fondo.

**Layout Paradigm:** Split-screen vertical: lado izquierdo con fondo vino y tipografía grande en crema; lado derecho con fondo crema y el formulario. En mobile colapsa a columna única.

**Signature Elements:**
- Numeración de secciones con tipografía serif grande (01, 02, 03)
- Líneas horizontales finas como separadores de sección
- Chips de información con borde vino y fondo transparente

**Interaction Philosophy:** Transiciones suaves al avanzar entre secciones; campos con borde inferior animado al foco; botón principal con efecto de llenado de izquierda a derecha.

**Animation:** Entrada de secciones con fade-up (200ms, ease-out). Checkboxes con scale(0.95→1) al seleccionar. Ficha de resultado con slide-in desde abajo.

**Typography System:** `Playfair Display` para títulos (bold, italic para énfasis); `Source Sans 3` para cuerpo y etiquetas. Jerarquía: 4rem / 2rem / 1.125rem / 0.875rem.

</text>
</response>

<response>
<probability>0.07</probability>
<text>

## Opción B — Minimalismo Técnico

**Design Movement:** Swiss International Style adaptado a interfaces digitales académicas.

**Core Principles:**
- Grid estricto de 12 columnas con márgenes generosos
- Tipografía sans-serif de peso variable como único recurso decorativo
- Formulario multi-paso con indicador de progreso lineal
- Datos y resultados presentados como tabla técnica

**Color Philosophy:** Fondo crema `#E9E2DA` como base neutra; vino `#401F28` exclusivamente para acciones primarias y encabezados; azul `#B5C5D4` para estados de éxito y chips de información.

**Layout Paradigm:** Una sola columna centrada con ancho máximo de 720px, secciones apiladas con separación generosa. El formulario avanza en pasos (wizard) con barra de progreso superior.

**Signature Elements:**
- Barra de progreso superior con segmentos de color vino
- Etiquetas flotantes en los campos de texto
- Tabla de resumen con filas alternadas crema/blanco

**Interaction Philosophy:** Cada paso del formulario se valida antes de avanzar; errores aparecen inline con animación de shake; el resumen final se construye en tiempo real.

**Animation:** Transición entre pasos con slide horizontal (250ms). Errores con shake de 300ms. Número de cursos seleccionados con contador animado.

**Typography System:** `DM Sans` variable para todo el sistema. Pesos: 300 (body), 500 (labels), 700 (títulos), 900 (números grandes). Escala: 3rem / 1.5rem / 1rem / 0.8rem.

</text>
</response>

<response>
<probability>0.08</probability>
<text>

## Opción C — Elegancia Institucional con Profundidad ✅ SELECCIONADA

**Design Movement:** Diseño institucional contemporáneo con influencias del Bauhaus tardío y el diseño de banca privada.

**Core Principles:**
- Profundidad visual mediante capas (fondo, tarjeta, elemento flotante)
- Paleta restringida aplicada con disciplina: vino para jerarquía, crema para espacio, azul para datos
- Formulario dividido en secciones numeradas con iconografía lineal
- Resumen en tiempo real como panel lateral o inferior

**Color Philosophy:** El vino `#401F28` como color de autoridad institucional en encabezados y botones; la crema `#E9E2DA` como superficie principal que evoca papel de calidad; el azul grisáceo `#B5C5D4` como color de datos y métricas.

**Layout Paradigm:** Header de marca fijo; cuerpo en dos columnas (formulario izquierda, resumen derecha en desktop); en mobile el resumen colapsa a panel inferior expandible.

**Signature Elements:**
- Tarjetas de sección con borde izquierdo vino de 3px y sombra sutil
- Panel de resumen con fondo vino y texto crema
- Indicadores de estado (cursos seleccionados, total) con tipografía grande

**Interaction Philosophy:** El resumen se actualiza en tiempo real al interactuar con el formulario; los checkboxes tienen estado visual claro (fondo vino al seleccionar); los errores aparecen como banners inline.

**Animation:** Fade-in de secciones al hacer scroll (150ms stagger). Panel de resumen con transición de altura suave. Botón de envío con efecto pulse al ser válido.

**Typography System:** `Cormorant Garamond` para el título principal y la marca (elegancia serif); `Inter` en peso 400/500/700 para todo lo funcional. Escala: 3.5rem / 2rem / 1.25rem / 1rem / 0.875rem.

</text>
</response>

---

## Decisión final: Opción C — Elegancia Institucional con Profundidad

Diseño institucional con paleta vino/crema/azul, layout de dos columnas, resumen en tiempo real y tipografía mixta Cormorant + Inter.
